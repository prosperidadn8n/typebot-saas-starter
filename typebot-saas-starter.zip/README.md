# Typebot SaaS Starter

This is a basic structure for a Typebot-based SaaS project.